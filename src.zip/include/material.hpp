#ifndef MATERIAL_H
#define MATERIAL_H

#include <cassert>
#include <vecmath.h>

#include "ray.hpp"
#include "hit.hpp"
#include <iostream>

// TODO: Implement Shade function that computes Phong introduced in class.
class Material
{
public:
    explicit Material(const Vector3f &d_color, const Vector3f &s_color = Vector3f::ZERO, float s = 0) : diffuseColor(d_color), specularColor(s_color), shininess(s)
    {
    }

    virtual ~Material() = default;

    virtual Vector3f getDiffuseColor() const
    {
        return diffuseColor;
    }

    Vector3f Shade(const Ray &ray, const Hit &hit,
                   const Vector3f &dirToLight, const Vector3f &lightColor)
    {
        Vector3f shaded = Vector3f::ZERO;
        //
        Vector3f R_i = 2 * (Vector3f::dot(hit.getNormal().normalized(), dirToLight.normalized())) * (hit.getNormal().normalized()) - dirToLight.normalized();
        // R_i = R_i.normalized();
        // std::cout << "lightColor: ";
        // lightColor.print();
        // std::cout << "diffuseColor: ";
        // diffuseColor.print();
        // std::cout << "specularColor: ";
        // specularColor.print();
        // std::cout << "normal: ";
        // hit.getNormal().normalized().print();
        Vector3f test = Vector3f::dot(dirToLight.normalized(), hit.getNormal().normalized());
        // std::cout << "test: ";
        // test.print();
        Vector3f v1 = this->diffuseColor * (std::max(float(0), Vector3f::dot(dirToLight.normalized(), hit.getNormal().normalized())));
        // std::cout << "v1: " << v1 << std::endl;
        Vector3f v2 = this->specularColor * pow(std::max(float(0), Vector3f::dot(-ray.getDirection().normalized(), R_i)), this->shininess);
        // std::cout << "v2: " << v2 << std::endl;
        shaded = lightColor * (v1 + v2);

        // std::cout << "shaded: ";
        // shaded.print();
        return shaded;
    }

protected:
    Vector3f diffuseColor;
    Vector3f specularColor;
    float shininess;
};

#endif // MATERIAL_H
