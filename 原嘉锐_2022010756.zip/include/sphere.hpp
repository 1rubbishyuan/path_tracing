#ifndef SPHERE_H
#define SPHERE_H

#include "object3d.hpp"
#include <vecmath.h>
#include <cmath>
#include <iostream>
// TODO: Implement functions and add more fields as necessary

class Sphere : public Object3D
{
public:
    Sphere()
    {
        // unit ball at the center
        this->center = Vector3f(0);
        this->radius = 1;
    }

    Sphere(const Vector3f &center, float radius, Material *material) : Object3D(material)
    {
        //
        this->center = center;
        this->radius = radius;
    }

    ~Sphere() override = default;

    bool intersect(const Ray &r, Hit &h, float tmin) override
    {
        // 判断r是否与这个球有交，并更新hit
        // std::cout << "k" << std::endl;
        Vector3f l = this->center - r.getOrigin();
        Vector3f unit_direction = r.getDirection().normalized();
        float t_p = Vector3f::dot(l, unit_direction);
        float length_l = l.length();
        if (t_p < 0 && length_l > this->radius)
        {
            // std::cout << "sphere0" << endl;
            return false;
        }
        if (length_l == this->radius)
        {
            if (tmin <= 0)
            {
                Vector3f n = (r.getOrigin() - this->center).normalized();
                h.set(0, this->material, n);
                return true;
            }
            // std::cout << "sphere1" << endl;
            return false;
        }
        float length_d = sqrt(length_l * length_l - t_p * t_p);
        if (length_d >= this->radius)
        {
            // std::cout << "sphere2" << endl;

            return false;
        }
        float t_pi = sqrt(this->radius * this->radius - length_d * length_d);
        float t = 0;
        if (length_l > this->radius)
            t = t_p - t_pi;
        else if (length_l < this->radius)
            t = t_p + t_pi;
        Vector3f n = (unit_direction * t + r.getOrigin() - this->center).normalized();
        // std::cout << "sphere: " << t << std::endl;
        if (h.getT() > t)
        {
            h.set(t, this->material, n);
            return true;
        }
        else
        {
            return false;
        }
    }

protected:
    Vector3f center;
    float radius;
};

#endif
