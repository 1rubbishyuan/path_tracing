#ifndef GROUP_H
#define GROUP_H

#include "object3d.hpp"
#include "ray.hpp"
#include "hit.hpp"
#include <iostream>
#include <vector>

// TODO: Implement Group - add data structure to store a list of Object*
class Group : public Object3D
{

public:
    Group()
    {
    }

    explicit Group(int num_objects)
    {
        this->all_object.resize(num_objects);
        this->num_objects = num_objects;
    }

    ~Group() override
    {
    }

    bool intersect(const Ray &r, Hit &h, float tmin) override
    {
        bool is_intersect = false;
        for (int i = 0; i < this->num_objects; i++)
        {
            // std::cout << i << std::endl;
            if (!is_intersect)
            {
                is_intersect = all_object[i]->intersect(r, h, tmin);
                // std::cout << i << std::endl;
            }
            else
            {
                bool m = all_object[i]->intersect(r, h, tmin);
            }
        }
        return is_intersect;
    }

    void addObject(int index, Object3D *obj)
    {
        all_object[index] = obj;
    }

    int getGroupSize()
    {
        return this->num_objects;
    }

private:
    std::vector<Object3D *> all_object;
    int num_objects;
};

#endif
